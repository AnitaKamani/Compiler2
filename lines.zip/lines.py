file1 = open('lines.txt', 'r')
file2 = open('lines2.txt', 'w')
lines = file1.readlines()
for line in lines:
    first = line.index("\"") + 1
    second = line[first:].index("\"") + first
    brace = line.index("{", 1)
    command = line[first:second]
    command2 = ""
    for c in command:
        command2 += "[" + c.lower() + c.upper() + "]"
    command2 += (50 - len(command2)) * " "
    command2 += line[brace:]
    file2.writelines(command2)

file2.close()
